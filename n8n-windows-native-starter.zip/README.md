# n8n Windows Native Starter (no Docker)

This starter gives you the simplest path to run **n8n on Windows**, and to **share workflows via Git**.

## 0) Install prerequisites
- Install **Node.js LTS**: `winget install OpenJS.NodeJS.LTS` (or download from nodejs.org)
- Install **n8n** globally: `npm install -g n8n`

## 1) Start n8n
```powershell
# From repo root
powershell -ExecutionPolicy Bypass -File .\scripts\start-n8n.ps1
```
- On first run, a config file is created at `scripts\n8n.env.json` (with a random encryption key).
- UI: http://localhost:5678 (Basic Auth defaults: `admin` / `devpass` — change them in the JSON file).

## 2) Export your workflows to Git
```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\export.ps1
git add .\workflows
git commit -m "chore: export workflows"
git push
```

## 3) Import teammates' workflows
```powershell
git pull
powershell -ExecutionPolicy Bypass -File .\scripts\import.ps1
```

## Repo layout
```
workflows/        # exported workflows (JSON) → COMMIT
scripts/          # start / export / import (PowerShell)
```

## Notes
- Credentials are stored in your Windows user profile (`%USERPROFILE%\.n8n`) and are encrypted using `N8N_ENCRYPTION_KEY` from `scripts\n8n.env.json`.
- Do not commit secrets; only commit `workflows/` JSON exports.
- If you ever want to match credentials across machines, reuse the same `N8N_ENCRYPTION_KEY`.
